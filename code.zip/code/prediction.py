from transformers import GPT2LMHeadModel, GPT2Tokenizer
import torch
import torch.nn.functional as F

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Load the tokenizer and model
model_name = "gpt2-large"  # or "gpt2-large" for the large version
tokenizer = GPT2Tokenizer.from_pretrained(model_name)
model = GPT2LMHeadModel.from_pretrained(model_name)
model.to(device)

# Set the model to evaluation mode
model.eval()

# Input text prompt
input_text = "Ludwig the cat"

# Tokenize the input text
input_ids = tokenizer.encode(input_text, return_tensors="pt")
input_ids = input_ids.to(device)

# Get the logits (unnormalized probabilities) for the next token
with torch.no_grad():
    outputs = model(input_ids)
    logits = outputs.logits[:, -1, :]  # Get logits for the last token in the sequence

# Apply softmax to convert logits to probabilities
probabilities = F.softmax(logits, dim=-1)

# Get the top 10 most probable next tokens
top_k = 10
top_k_probabilities, top_k_indices = torch.topk(probabilities, top_k)

# Decode the top 10 token indices into words
top_k_tokens = [tokenizer.decode([idx]) for idx in top_k_indices[0]]

# Print the top 10 tokens and their probabilities
for token, prob in zip(top_k_tokens, top_k_probabilities[0]):
    print(f"Token: {token}, Probability: {prob.item():.4f}")

# Report the probability of the most probable next token
most_probable_token = top_k_tokens[0]
most_probable_token_probability = top_k_probabilities[0].item()

print(f"Most probable next token: {most_probable_token}, Probability: {most_probable_token_probability:.4f}")
