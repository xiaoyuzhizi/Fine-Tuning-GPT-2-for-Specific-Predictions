# README

This folder contains three Python scripts that demonstrate the use of GPT-2 for fine-tuning, prediction, and handling tokenized prompts. Below is a detailed description of each file:

## Files

### 1. `prediction.py`
- **Purpose**: Generates predictions for the most probable next tokens given an input prompt.
- **Key Features**:
  - Loads the GPT-2 model and tokenizer.
  - Computes the logits for the last token of the input sequence.
  - Displays the top 10 most probable next tokens along with their probabilities.
- **Usage**:
  - Use this script to explore the model's predictions and understand its behavior for specific inputs.


### 2. `finetuning.py`
- **Purpose**: Implements a fine-tuning process for GPT-2 using a small dataset. It focuses on improving the model's ability to predict a specific target word based on a given input prompt.
- **Key Features**:
  - Uses the `Adam` optimizer and cross-entropy loss for training.
  - Computes the probability of the target word both before and after fine-tuning.
  - Provides debug outputs for tokenized inputs, logits, and probabilities.
- **Usage**:
  - Run the script to observe how fine-tuning affects the model's ability to predict the target word.


### 3. `prompt.py`
- **Purpose**: Focuses on the manipulation of token embeddings and fine-tuning specific layers in GPT-2.
- **Key Features**:
  - Freezes all model parameters except the embedding layer.
  - Calculates the probability of a target word based on a given input prompt.
  - Includes a fine-tuning loop to adjust only the embedding layer parameters.
- **Usage**:
  - Run the script to explore how adjusting embedding layers impacts the prediction probability.

## Requirements
- Python 3.8 or higher
- PyTorch
- Transformers library by Hugging Face
- GPU (optional but recommended for faster computation)

## How to Run
1. Install the required libraries:
   ```bash
   pip install torch transformers
   ```
2. Execute the scripts individually using Python:
   ```bash
   python finetuning.py
   python prediction.py
   python prompt.py
   ```