from transformers import GPT2LMHeadModel, GPT2Tokenizer
import torch
import torch.nn.functional as F
from torch.optim import Adam

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Load the tokenizer and model
model_name = "gpt2-large"  # You can change to "gpt2-large" for a larger model
tokenizer = GPT2Tokenizer.from_pretrained(model_name)
model = GPT2LMHeadModel.from_pretrained(model_name)
model.to(device)

# Set the model to evaluation mode
model.eval()

# Input text prompt
input_text = "Ludwig the catstretches"
target_text = "stretches"  # The target word we want to predict after the prompt

# Tokenize the input text
input_ids = tokenizer.encode(input_text, return_tensors="pt").to(device)
target_ids = tokenizer.encode(target_text, return_tensors="pt").to(device)

# Debug: print shapes of tokenized input and target
print(f"input_ids shape: {input_ids.shape}")
print(f"target_ids shape: {target_ids.shape}")

# Freeze all parameters except the embeddings
for param in model.parameters():
    param.requires_grad = False

# Only unfreeze the noncontextualized subword embeddings (model's word embeddings)
embedding_layer = model.transformer.wte  # Word token embeddings layer
for param in embedding_layer.parameters():
    param.requires_grad = True  # Ensure the embedding layer parameters require gradients


# You can identify the subwords for "Ludwig the cat" here
input_tokens = tokenizer.encode(input_text)
target_tokens = tokenizer.encode(target_text)

# Get the specific indices of the subwords for "Ludwig the cat"
# This is important to know which embeddings are being adjusted
print(f"Subwords for input text '{input_text}': {[tokenizer.decode([token]) for token in input_tokens]}")
print(f"Subwords for target text '{target_text}': {[tokenizer.decode([token]) for token in target_tokens]}")

# Define optimizer and learning rate (only for the embedding layer)
optimizer = Adam(embedding_layer.parameters(), lr=1e-5)


# Function to calculate the probability of the target word
def get_target_probability(input_ids, target_ids):
    with torch.no_grad():
        # Get the logits for the entire input sequence, including the target sequence
        outputs = model(input_ids)

        # Debug: print the shape of the logits
        print(f"Logits shape: {outputs.logits.shape}")

        logits = outputs.logits[:, -4:-1, :]  # Get logits for the target sequence
        print(f"logits shape: {logits.shape}")

        probabilities = F.softmax(logits, dim=-1)
        # Debug: print the shape of the probabilities
        print(f"Probabilities shape: {probabilities.shape}")

        # Initialize the total probability (product of probabilities for each token)
        total_probability = 1.0

        # Iterate over the target_ids and calculate the probability for each token
        for i in range(3):
            target_token_id = target_ids[0][i]
            token_probability = probabilities[0, i, target_token_id].item()  # Probability for the i-th token
            print(f"Probability of token {target_token_id} ({tokenizer.decode([target_token_id])}): {token_probability:.4f}")

            total_probability *= token_probability  # Multiply the probabilities for each token

    return total_probability


# Initial probability of predicting the word "stretches"
initial_probability = get_target_probability(input_ids, target_ids)
print(f"Initial probability of predicting 'stretches': {initial_probability:.12f}")

# Define the loss function (Negative Log-Likelihood)
loss_function = torch.nn.CrossEntropyLoss()
model.train()

# Training loop (just a few steps since we're fine-tuning)
for epoch in range(5):  # You can increase the number of epochs for better fine-tuning
    optimizer.zero_grad()  # Reset gradients

    # Get the logits for the entire sequence (input text + target word)
    outputs = model(input_ids)
    logits = outputs.logits[:, -4:-1, :]  # Get logits for the target token

    # Calculate the loss between the predicted logits and the target token
    loss = loss_function(logits.view(-1, logits.size(-1)), target_ids.view(-1))

    # Backpropagation and optimization step
    loss.backward()
    optimizer.step()

    print(f"Epoch {epoch + 1}, Loss: {loss.item():.4f}")
model.eval()
# After fine-tuning, check the probability of predicting the word "stretches"
final_probability = get_target_probability(input_ids, target_ids)
print(f"Final probability of predicting 'stretches': {final_probability:.12f}")
